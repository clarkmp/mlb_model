# MLB Historical Odds Web Scraper

## Overview
This is a web scraper that collects historical MLB betting odds from [SportsBookReview](https://www.sportsbookreview.com), and saves it in JSON format. The data contains information about Point Spread, Money Line, and Totals odds from multiple sportsbooks, including DraftKings, Bet365, and FanDuel. The repo also contains a downloadable [dataset](mlb_odds_dataset.json) (76 MB) for all odds in the date range 2021-03-20 to 2025-08-16.

## Why?
Having historical odds data is good for training machine learning models and backtesting betting strategies. However, it's pretty hard to get free odds data. Most APIs' free tiers are very limited and there's not really any free datasets online.

## Usage
### Download and Setup
Paste the commands line by line into terminal:

1. Clone the repository
```bash
git clone https://github.com/ArnavSaraogi/mlb-odds-scraper
cd mlb-odds-scraper
```

2. Set up virtual environment and install requirements
```bash
python3 -m venv venv
source venv/bin/activate # on Windows, the command is venv\Scripts\activate
```

3. Install requirements
```bash
pip install -r requirements.txt
```

### Running the Scraper
Once you have the directory set up, use terminal to run:
```bash
python scraper.py <start_date> <end_date>
```

There are also some optional flags:

| Flag | Description |
|------|-------------|
| `-t`, `--type` | The type of odds (`moneyline`, `pointspread`, `totals`) that you want to retrieve; enter them separated by a space. **Default:** `moneyline` |
| `-c`, `--concurrent` | How many HTTP requests the scraper can make at once. **Default:** `5` |
| `-f`, `--fast` | Decreases the sleep time between requests, making the scraping faster |
| `-o`, `--output` | The filename of the JSON output. **Default:** `mlb_odds.json` |


So, an example of running the app is:
```bash
python scraper.py 2021-03-20 2025-08-16 -t moneyline pointspread -c 8 -o my_data.json -f
```

## JSON Structure
The data is organized by date. Each date contains a list of games, with game details and sportsbook odds. Here's what the structure looks like:

```json
{
  "2024-04-01": [
    {
      "gameView": {
        "startDate": "...",
        "awayTeam": {...},
        "homeTeam": {...},
        // ... other game info
      },
      "odds": {
        "moneyline": [
          {
            "sportsbook": "DraftKings",
            "openingLine": {"homeOdds": -120, "awayOdds": 110},
            "currentLine": {"homeOdds": -115, "awayOdds": 105}
          }
        ],
        "pointspread": [...],
        "totals": [...]
      }
    }
  ]
}
```

## Notes
1. It seems that historical odds data is reliably available on SportsBookReview starting 2019-05-03, so I recomend scraping from that as the earliest
2. The reason --fast is a flag (and not just the default) is because SportsBookReview may have anti-bot protections and block you if you're sending too many requests too quickly.
3. The gameType field in gameView is taken from the MLB API for the specific game. It specifies what type of game it is:
    * "R": Regular Season
    * "S": Spring Training
    * "E": Exhibition
    * "A": All-Star Game
    * "D": Division Series
    * "F": First Round (Wild Card)
    * "L": League Championship
    * "W": World Series
4. Make sure your computer doesn't sleep while you're running the script, otherwise the scraper will pause/fail.

## Alternatives
1. https://github.com/flancast90/sportsbookreview-scraper: this is another SportBookReview scraper, which also supports sports beyond just MLB. However, it doesn't have odds from different sportsbooks, and seems to just have an aggregated moneyline odds.
2. Different APIs that provide sports odds. The most popular ones include [The Odds API](https://the-odds-api.com/), [SportsDevs](https://sportdevs.com/), and [API Football](https://dashboard.api-football.com/). However, free tiers are limited and some don't even provide historical data in the free.

## Disclaimer
This tool is for educational/demonstrational purposes only. Please review SportsBookReview’s Terms of Service before scraping, and use responsibly.